// exports.API_ROOT_URL = "http://52.221.206.226/api/v1"; // production URL
exports.API_ROOT_URL = "http://aaac49077c01.ngrok.io/api/v1"; // local URL
exports.LOCAL_AUTH_KEY = "LOCAL_AUTH_KEY";
exports.AXIOS_HEADER_AUTH_KEY = "X-Authorization";
