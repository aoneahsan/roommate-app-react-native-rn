// exports.API_ROOT_URL = "http://f69b95fee775.ngrok.io/api/v1"; // production URL
// exports.API_ROOT_URL = "http://localhost:3020/api/v1"; // local URL
exports.API_ROOT_URL = "http://f69b95fee775.ngrok.io/api/v1"; // local URL
exports.LOCAL_AUTH_KEY = "LOCAL_AUTH_KEY";
exports.AXIOS_HEADER_AUTH_KEY = "X-Authorization";
